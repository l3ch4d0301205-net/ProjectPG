from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from PIL import Image
import sys

# Variables
textureID = None
angle = 0

# Cargar texturas del skybox
def load_skybox_textures():
    faces = ["right.jpg", "left.jpg", "top.jpg", "bottom.jpg", "front.jpg", "back.jpg"]
    targets = [
        GL_TEXTURE_CUBE_MAP_POSITIVE_X, GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
        GL_TEXTURE_CUBE_MAP_POSITIVE_Y, GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
        GL_TEXTURE_CUBE_MAP_POSITIVE_Z, GL_TEXTURE_CUBE_MAP_NEGATIVE_Z
    ]

    texID = glGenTextures(1)
    glBindTexture(GL_TEXTURE_CUBE_MAP, texID)

    for i in range(6):
        try:
            img = Image.open(faces[i])

            # ⬇ Redimensionar si es muy grande
            max_size = 1024
            if img.width > max_size or img.height > max_size:
                img = img.resize((max_size, max_size), Image.LANCZOS)

            img = img.transpose(Image.FLIP_TOP_BOTTOM)
            img_data = img.convert("RGB").tobytes()

            glTexImage2D(targets[i], 0, GL_RGB, img.width, img.height, 0, GL_RGB, GL_UNSIGNED_BYTE, img_data)
        except Exception as e:
            print(f"Error loading {faces[i]}: {e}")
            sys.exit()

    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE)

    return texID


# Dibujar cubo del skybox
def draw_skybox(size=50.0):
    glBindTexture(GL_TEXTURE_CUBE_MAP, textureID)
    glBegin(GL_QUADS)

    # Right
    glTexCoord3f(1.0, -1.0, -1.0); glVertex3f(size, -size, -size)
    glTexCoord3f(1.0, -1.0,  1.0); glVertex3f(size, -size, size)
    glTexCoord3f(1.0,  1.0,  1.0); glVertex3f(size, size, size)
    glTexCoord3f(1.0,  1.0, -1.0); glVertex3f(size, size, -size)

    # Left
    glTexCoord3f(-1.0, -1.0,  1.0); glVertex3f(-size, -size, size)
    glTexCoord3f(-1.0, -1.0, -1.0); glVertex3f(-size, -size, -size)
    glTexCoord3f(-1.0,  1.0, -1.0); glVertex3f(-size, size, -size)
    glTexCoord3f(-1.0,  1.0,  1.0); glVertex3f(-size, size, size)

    # Top
    glTexCoord3f(-1.0, 1.0, -1.0); glVertex3f(-size, size, -size)
    glTexCoord3f( 1.0, 1.0, -1.0); glVertex3f(size, size, -size)
    glTexCoord3f( 1.0, 1.0,  1.0); glVertex3f(size, size, size)
    glTexCoord3f(-1.0, 1.0,  1.0); glVertex3f(-size, size, size)

    # Bottom
    glTexCoord3f(-1.0, -1.0,  1.0); glVertex3f(-size, -size, size)
    glTexCoord3f( 1.0, -1.0,  1.0); glVertex3f(size, -size, size)
    glTexCoord3f( 1.0, -1.0, -1.0); glVertex3f(size, -size, -size)
    glTexCoord3f(-1.0, -1.0, -1.0); glVertex3f(-size, -size, -size)

    # Front
    glTexCoord3f(-1.0, -1.0, -1.0); glVertex3f(-size, -size, -size)
    glTexCoord3f( 1.0, -1.0, -1.0); glVertex3f(size, -size, -size)
    glTexCoord3f( 1.0,  1.0, -1.0); glVertex3f(size, size, -size)
    glTexCoord3f(-1.0,  1.0, -1.0); glVertex3f(-size, size, -size)

    # Back
    glTexCoord3f( 1.0, -1.0, 1.0); glVertex3f(size, -size, size)
    glTexCoord3f(-1.0, -1.0, 1.0); glVertex3f(-size, -size, size)
    glTexCoord3f(-1.0,  1.0, 1.0); glVertex3f(-size, size, size)
    glTexCoord3f( 1.0,  1.0, 1.0); glVertex3f(size, size, size)

    glEnd()

# Mostrar escena
def display():
    global angle
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    # Cámara fija girando
    gluLookAt(0, 0, 0, 0, 0, -1, 0, 1, 0)
    glRotatef(angle, 0, 1, 0)

    glEnable(GL_TEXTURE_CUBE_MAP)
    draw_skybox()
    glDisable(GL_TEXTURE_CUBE_MAP)

    glutSwapBuffers()

# Animación
def idle():
    global angle
    angle += 0.1
    if angle > 360:
        angle -= 360
    glutPostRedisplay()

# Inicializar OpenGL
def init():
    glEnable(GL_DEPTH_TEST)
    glClearColor(0.0, 0.0, 0.0, 1.0)

# Programa principal
def main():
    global textureID
    glutInit()
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
    glutInitWindowSize(800, 600)
    glutCreateWindow(b"Skybox en OpenGL")
    init()
    textureID = load_skybox_textures()
    glutDisplayFunc(display)
    glutIdleFunc(idle)
    glutMainLoop()

if __name__ == "__main__":
    main()


